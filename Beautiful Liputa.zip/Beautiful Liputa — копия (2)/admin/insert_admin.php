<?php
$host = 'localhost';
$dbname = 'onlineshopbl_db';
$user = 'root';
$pass = 'LaulauJoy@2003'; // ou ton mot de passe MySQL

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $password = 'admin123';
    $hash = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("INSERT INTO Admin (Full_Name, Email, Admin_Password) VALUES (?, ?, ?)");
    $stmt->execute(['Admin Test', 'admin@example.com', $hash]);

    echo "Admin ajouté avec succès.";
} catch (PDOException $e) {
    echo "Erreur : " . $e->getMessage();
}
?>
